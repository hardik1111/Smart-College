# smart-college
centralize application for document and information sharing for college 
